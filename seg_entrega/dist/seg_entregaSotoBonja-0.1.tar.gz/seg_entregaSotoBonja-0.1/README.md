## Segunda pre-entrega del proyecto final

### _Consigna_

**Objetivo**

- Practicar el concepto de Clases y Objetos.

**Consigna**

- Crear un programa que permita el modelamiento de Clientes en una página de compras. Se debe utilizar el concepto de Programación Orientada a Objetos y lo aprendido en clase.
- Se evaluará el uso correcto de atributos y métodos.
- Utilizar los conceptos aprendidos en la clase 15 y crear un paquete redistribuible con el programa creado."

**Formato**

- El proyecto debe ser un archivo comprimido del paquete. Formatos aceptados: .zip o .tar.gz bajo el nombre “Segunda pre-entrega+Apellido”.

**Se debe entregar**

- Se debe entregar todo el programa.

**Sugerencias**

- "La Clase Cliente debe tener mínimo 4 atributos y 2 métodos.
- Se debe utilizar el método **str**() para darle nombre a los objetos.
- Para crear el paquete distribuible también como adicional el archivo de la Pre entrega #1.
- Es opcional el uso de herencia."
