class Client:
    def __init__(self, first_name, last_name, age, email, address, phone, date_of_birth, sex, identity_number ) :
        self.first_name = first_name
        self.last_name = last_name
        self.age = age
        self.email = email
        self.address = address
        self.phone = phone
        self.date_of_birth = date_of_birth
        self.sex = sex
        self.identity_number = identity_number
        self.shopping_cart = []

    def add_product_to_cart(self, product):
         self.shopping_cart.append(product)

    def make_purchase(self):
         total = sum(product.price for product in self.shopping_cart)
         print(f"Cliente {self.first_name} ha realizado una compra por un total de ${total}.")
         self.shopping_cart = []

    def __str__(self):
         return f"Cliente: {self.first_name}\nEmail: {self.email}\nDirección: {self.address}\nTeléfono: {self.phone}"
    


cliente1 = Client("Juan", "Pérez", "juan.perez@example.com", "Calle 123, Ciudad de México", "555-555-5555","Masculino", "INE", "123456789")
print(cliente1)

cliente2 = Client("María", "García", "maria.garcia@example.com", "Avenida 456, Guadalajara", "333-333-3333", "Femenino", "Pasaporte", "987654321")
print(cliente2)