from setuptools import setup

setup(
    name="seg_entregaSotoBonja",
    version="0.1",
    packages=["seg_entregaSotoBonja"],
    install_requires=[],
)
