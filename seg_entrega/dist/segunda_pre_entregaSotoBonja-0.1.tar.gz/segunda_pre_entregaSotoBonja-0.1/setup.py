from setuptools import setup

setup(
    name="segunda_pre_entregaSotoBonja",
    version="0.1",
    description="Primer paquete distribuido",
    author="Clase CODER - Python",
    author_email="lucianosotobonja95@gmail.com",

    packages=["seg_entregaSotoBonja"],
)
